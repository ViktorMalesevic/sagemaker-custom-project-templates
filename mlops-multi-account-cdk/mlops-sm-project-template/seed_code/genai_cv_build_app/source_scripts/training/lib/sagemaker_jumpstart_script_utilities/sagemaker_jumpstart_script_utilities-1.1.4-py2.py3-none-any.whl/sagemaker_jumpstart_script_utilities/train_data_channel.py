import argparse


def assign_train_argument(args: argparse.Namespace) -> None:
    """Determine training data directory from the argument, mutate args.train if necessary.

    Allows users to pass in training data through either 'train' or 'training' channel.

    Args:
        args (argparse.Namespace): model arguments passed by SageMaker DLC.

    Raises:
        ValueError if both training and train channels are set, or if neither of them are set.
    """

    if args.train is not None and args.train_alt is not None:
        raise ValueError(
            "Both 'train' and 'training' channel are identified. "
            "Could not resolve ambiguity on which channel to use to read training data. "
            "Please specify only one of 'train' or 'training' channel and try again."
        )
    if args.train is None and args.train_alt is not None:
        args.train = args.train_alt
    if args.train is None and args.train_alt is None:
        raise ValueError(
            "Neither 'train' nor 'training' channel is identified. "
            "Please specify one of 'train' or 'training' channel to pass in training data and try again."
        )
