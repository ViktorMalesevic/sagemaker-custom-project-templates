import argparse
from typing import Optional
from typing import Union


LOW_TRUE_STR = "true"
LOW_FALSE_STR = "false"
NONE_STR = "None"


def str2bool(v: str) -> bool:
    """Convert string argument to a boolean value."""
    if v.lower() == LOW_TRUE_STR:
        return True
    elif v.lower() == LOW_FALSE_STR:
        return False
    else:
        raise argparse.ArgumentTypeError("Boolean value expected.")


def str2optionalint(v: str) -> Optional[int]:
    """Convert string argument to optional int."""
    if v == NONE_STR:
        return None
    else:
        try:
            return int(v)
        except Exception as e:
            raise argparse.ArgumentTypeError(f"Integer or None expected. Error: {e}.")


def str2optionalstr(v: str) -> Optional[str]:
    """Convert a string argument to optional string argument."""
    if v == NONE_STR:
        return None
    elif isinstance(v, str):
        return v
    else:
        raise argparse.ArgumentTypeError("None or string value expected.")
